# ARB-2 (Fabric, Minecraft Java 1.21.1)

## Como usar no jogo
- Pegue o item **ARB-2** (aba Ferramentas no criativo, ou receita: 3 blocos de ferro / 2 concreto azul-claro + para-raios / 3 concreto preto)
- Clique com o botão direito no chão para colocar
- Botão direito no veículo = entrar (2 lugares) | W/S acelera/ré | A/D vira
- **Shift + botão direito** no veículo = cravar/recolher as âncoras (trava no lugar)
- Bater no veículo (fora dele) = recolhe o item

## Como compilar
1. Instale o JDK 21
2. Gere um projeto base em https://fabricmc.net/develop/template/ (1.21.1) e copie a pasta `src` e os arquivos
   `build.gradle` / `gradle.properties` deste projeto por cima (ou use o wrapper do template)
3. Rode `./gradlew build` -> o .jar fica em `build/libs/`
4. Coloque o .jar (sem o -sources) na pasta `mods` junto com o Fabric API
