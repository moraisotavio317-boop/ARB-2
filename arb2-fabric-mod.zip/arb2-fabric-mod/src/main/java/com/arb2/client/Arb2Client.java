package com.arb2.client;

import com.arb2.Arb2Mod;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;

public class Arb2Client implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		EntityRendererRegistry.register(Arb2Mod.ARB2_ENTITY, Arb2Renderer::new);
	}
}
