package com.arb2;

import net.minecraft.item.Item;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/** Item que coloca o ARB-2 no chão. */
public class Arb2Item extends Item {
	public Arb2Item(Settings settings) {
		super(settings);
	}

	@Override
	public ActionResult useOnBlock(ItemUsageContext ctx) {
		World world = ctx.getWorld();
		if (world.isClient) return ActionResult.SUCCESS;

		BlockPos pos = ctx.getBlockPos().offset(ctx.getSide());
		Arb2Entity vehicle = new Arb2Entity(Arb2Mod.ARB2_ENTITY, world);
		vehicle.refreshPositionAndAngles(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, ctx.getPlayerYaw(), 0f);
		world.spawnEntity(vehicle);
		ctx.getStack().decrementUnlessCreative(1, ctx.getPlayer());
		return ActionResult.CONSUME;
	}
}
