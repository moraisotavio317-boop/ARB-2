package com.arb2;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.MovementType;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

/**
 * ARB-2: veículo de 2 lugares.
 *  - W/S acelera/ré, A/D esterça (igual a um carro)
 *  - Shift + botão direito no veículo: crava / solta as âncoras (trava o veículo no lugar)
 *  - Sobe degraus de 1 bloco sozinho (a rampa da frente "empurra" o terreno)
 */
public class Arb2Entity extends Entity {
	private static final TrackedData<Boolean> ANCHORED =
		DataTracker.registerData(Arb2Entity.class, TrackedDataHandlerRegistry.BOOLEAN);

	private static final double MAX_FORWARD = 0.75;  // blocos/tick (~15 b/s)
	private static final double MAX_REVERSE = 0.25;
	private static final double ACCEL = 0.02;
	private static final double BRAKE = 0.05;

	public Arb2Entity(EntityType<? extends Arb2Entity> type, World world) {
		super(type, world);
	}

	@Override
	protected void initDataTracker(DataTracker.Builder builder) {
		builder.add(ANCHORED, false);
	}

	public boolean isAnchored() {
		return this.dataTracker.get(ANCHORED);
	}

	public void setAnchored(boolean anchored) {
		this.dataTracker.set(ANCHORED, anchored);
	}

	@Override
	protected void readCustomDataFromNbt(NbtCompound nbt) {
		setAnchored(nbt.getBoolean("Anchored"));
	}

	@Override
	protected void writeCustomDataToNbt(NbtCompound nbt) {
		nbt.putBoolean("Anchored", isAnchored());
	}

	@Override
	public boolean canHit() {
		return !this.isRemoved();
	}

	// ---------------------------------------------------------------- interação

	@Override
	public ActionResult interact(PlayerEntity player, Hand hand) {
		if (player.shouldCancelInteraction()) {
			if (!getWorld().isClient) {
				setAnchored(!isAnchored());
				player.sendMessage(Text.translatable(isAnchored() ? "message.arb2.anchored" : "message.arb2.released"), true);
				getWorld().playSound(null, getBlockPos(),
					isAnchored() ? SoundEvents.BLOCK_PISTON_EXTEND : SoundEvents.BLOCK_PISTON_CONTRACT,
					SoundCategory.NEUTRAL, 1.0f, 0.8f);
			}
			return ActionResult.success(getWorld().isClient);
		}
		if (getPassengerList().size() >= 2) return ActionResult.PASS;
		if (!getWorld().isClient) {
			return player.startRiding(this) ? ActionResult.CONSUME : ActionResult.PASS;
		}
		return ActionResult.SUCCESS;
	}

	@Override
	public boolean damage(DamageSource source, float amount) {
		if (isInvulnerableTo(source)) return false;
		if (getWorld().isClient || isRemoved()) return true;
		if (source.getAttacker() instanceof PlayerEntity p && !hasPassenger(p)) {
			if (!p.isCreative()) dropStack(new ItemStack(Arb2Mod.ARB2_ITEM));
			discard();
			return true;
		}
		return false;
	}

	// ---------------------------------------------------------------- passageiros

	@Override
	protected boolean canAddPassenger(Entity passenger) {
		return getPassengerList().size() < 2;
	}

	@Nullable
	@Override
	public LivingEntity getControllingPassenger() {
		return getFirstPassenger() instanceof LivingEntity le ? le : null;
	}

	/** Banco 0 = motorista (esquerda), banco 1 = carona (direita), dentro da cabine. */
	@Override
	protected Vec3d getPassengerAttachmentPos(Entity passenger, EntityDimensions dimensions, float scaleFactor) {
		int index = getPassengerList().indexOf(passenger);
		double x = index <= 0 ? 0.45 : -0.45;
		return new Vec3d(x, 0.9, 0.95).rotateY(-this.getYaw() * ((float) Math.PI / 180f));
	}

	// ---------------------------------------------------------------- movimento

	@Override
	public void tick() {
		super.tick();
		if (this.isLogicalSideForUpdatingMovement()) {
			this.drive();
			this.move(MovementType.SELF, this.getVelocity());
		} else {
			this.setVelocity(Vec3d.ZERO);
		}
	}

	private void drive() {
		LivingEntity pilot = getControllingPassenger();
		boolean anchored = isAnchored();
		float throttle = 0f;
		float steer = 0f;
		if (pilot != null && !anchored) {
			throttle = pilot.forwardSpeed;   // W = +, S = -
			steer = pilot.sidewaysSpeed;     // A = + (esquerda), D = - (direita)
		}

		Vec3d vel = getVelocity();
		float yawRad = getYaw() * ((float) Math.PI / 180f);
		double fx = -MathHelper.sin(yawRad);
		double fz = MathHelper.cos(yawRad);
		double speed = vel.x * fx + vel.z * fz;

		if (anchored) {
			speed = 0;
		} else if (throttle == 0) {
			speed *= 0.94;
			if (Math.abs(speed) < 0.003) speed = 0;
		} else {
			double target = throttle > 0 ? throttle * MAX_FORWARD : throttle * MAX_REVERSE;
			speed += MathHelper.clamp(target - speed, -BRAKE, ACCEL);
		}

		// direção só funciona em movimento (e inverte na ré)
		if (steer != 0 && Math.abs(speed) > 0.02) {
			float grip = (float) Math.min(1.0, Math.abs(speed) / 0.3);
			setYaw(getYaw() - steer * 3.2f * grip * (float) Math.signum(speed));
			yawRad = getYaw() * ((float) Math.PI / 180f);
			fx = -MathHelper.sin(yawRad);
			fz = MathHelper.cos(yawRad);
		}

		double vy;
		if (isOnGround()) {
			// "pulinho" automático pra subir degraus de 1 bloco
			vy = (this.horizontalCollision && Math.abs(speed) > 0.05) ? 0.42 : -0.05;
		} else {
			vy = (vel.y - 0.08) * 0.98;
		}
		setVelocity(fx * speed, vy, fz * speed);
	}
}
