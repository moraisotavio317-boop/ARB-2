package com.arb2;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class Arb2Mod implements ModInitializer {
	public static final String MOD_ID = "arb2";

	public static final EntityType<Arb2Entity> ARB2_ENTITY = Registry.register(
		Registries.ENTITY_TYPE,
		Identifier.of(MOD_ID, "arb2"),
		FabricEntityTypeBuilder.<Arb2Entity>create(SpawnGroup.MISC, Arb2Entity::new)
			.dimensions(EntityDimensions.fixed(3.2f, 2.6f))
			.trackRangeBlocks(100)
			.trackedUpdateRate(1)
			.build()
	);

	public static final Item ARB2_ITEM = Registry.register(
		Registries.ITEM,
		Identifier.of(MOD_ID, "arb2"),
		new Arb2Item(new Item.Settings().maxCount(1))
	);

	@Override
	public void onInitialize() {
		ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(entries -> entries.add(ARB2_ITEM));
	}
}
